<!DOCTYPE html>
<html lang="en">
<?php session_start(); ?>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style3.css">
    <title>Document</title>
</head>

<?php 
	include("connection.php");
	
	$userId =$_SESSION['id'];
	
	
	
	$result = mysqli_query($mysqli, "SELECT * FROM cv_profile WHERE username='$userId' ");
	
	$row = mysqli_fetch_array($result);
	
	$result2 = mysqli_query($mysqli, "SELECT * FROM exp WHERE user_id='$userId'")
					or die("Could not execute the select query.");

                    $res2 = mysqli_fetch_array($result2);
		
?>
<body>
    <div class="container">
        <div class="one">
            <div id="profile_picture_section">
                <div class="round"></div>
            </div>

            <section class="about_me_section">
                <div class="icon">
                    <div class="icon_round">
                        <img src="images/Forma 1.png" alt="">
                    </div>
                </div>
                <div class="details">
                    <h2>About Me</h2>
                    <p><?php echo $row['about'] ?></p>
                </div>
            </section>

            <section class="contact_section">
                <div class="icon">
                    <div class="icon_round_tall">
                        <div><img src="images/phone.png" alt=""></div>
                        <div><img src="images/gmail.png" alt=""></div>
                        <div><img src="images/home copy.png" alt=""></div>
                    </div>
                </div>
                <div class="details">
                    <h2>Contact</h2>
                    <p><?php echo $row['phone'] ?></p>
                    <p><?php echo $row['email'] ?></p>
                    <p><?php echo $row['address'] ?></p>
                </div>
            </section>

            <section class="education_section">
                <div class="icon">
                    <div class="icon_round">
                        <img src="images/Rectangle 2 copy.png" alt="">
                    </div>
                </div>
                <div class="details">
                    <h2>Education</h2>
                    <div class="sec">
                        <p>2014 - 2016 <br>
                            <div class="ins">
                                <p>Master’s Degree</p>
                            </div>
                            <p>University name here </p><br>
                        </p>
                    </div>
                    <div class="sec">
                        <p>2014 - 2016 <br>
                            <div class="ins">
                                <p>Master’s Degree</p>
                            </div>
                            <p>University name here </p><br>
                        </p>
                    </div>
                    <div class="sec">
                        <p>2014 - 2016 <br>
                            <div class="ins">
                                <p>Master’s Degree</p>
                            </div>
                            <p>University name here </p><br>
                        </p>
                    </div>
                </div>
            </section>
        </div>


        <div class="two">
            <div id="profile_name_section">
                <p id="name"><?php echo $row['name'] ?></span></p>
                <p id="pro"><?php echo $row['position'] ?></p>
            </div>

            <section id="experience_section">
                <div class="details">
                    <h2>Experience</h2>
                    <div class="sec">
						<p id="company_name"><?php echo $res2['company_name']?></p>
                        <p id="date"><?php echo $res2['date']?></p>
						<p id="possition"><?php echo $res2['possition']?></p>	
                        <p id="description"><?php echo $res2['description']?></p>						
						   
                    </div>

                    
					
                </div>
            </section>

            <section id="professional_skills_section">
                <div class="details">
                    <h2>Professional Skills</h2>
                    <div class="sec ps">
                        <p>Photoshop</p>
                        <div class="bar"></div>
                    </div>
                    <div class="sec ai">
                        <p>Illustrator</p>
                        <div class="bar"></div>
                    </div>
                    <div class="sec in">
                        <p>Indesign</p>
                        <div class="bar"></div>
                    </div>
                    <div class="sec af">
                        <p>After Effect</p>
                        <div class="bar"></div>
                    </div>
                    <div class="sec sk">
                        <p>Sketch</p>
                        <div class="bar"></div>
                    </div>
                </div>
            </section>

            <section id="interests_section">
                <div class="details">
                    <h2>Interests</h2>
                    <ul>
                        <li>
                            <p>Gaming</p>
                        </li>
                        <li>
                            <p>Travelling</p>
                        </li>
                        <li>
                            <p>Singing</p>
                        </li>
                        <li>
                            <p>Sketching</p>
                        </li>
                    </ul>
                </div>
            </section>
        </div>
    </div>
</body>

</html>